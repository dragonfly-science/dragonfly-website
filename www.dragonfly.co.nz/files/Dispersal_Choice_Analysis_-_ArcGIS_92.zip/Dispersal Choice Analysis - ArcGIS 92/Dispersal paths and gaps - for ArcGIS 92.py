# ---------------------------------------------------------------------------
# Dispersal paths and gaps - for ArcGIS 92.py
# Created on: Fri Nov 28 2008 
# by Yvan Richard (y.richard@massey.ac.nz - http://www.massey.ac.nz/~yrichard)
# ---------------------------------------------------------------------------
# Last updated: 3-Mar-2009

# DESCRIPTION:
# Creates least-cost paths from series of consecutive dispersal locations, based on a given cost raster representing the landscape frictions.
# This tool also extracts the maximum distance crossed by each path over a certain vegetation type.

# REQUIREMENTS:
# Every points in the observed points shapefile should have an index of the individual and a point index (indicating the chronological order)
# and should be sorted by individual and time
# The input points can be in different shapefiles, as long as the points of one individual are in the same one.
# Several individuals can be placed in the same shapefile.


# ARGUMENTS:
# 1: Indiv_AllPoints            point shapefile with individual and point ID fields.
# 2: IndivIDField               name of the individual ID field.
# 3: PtField                    name of the point ID field.
# 4: CostWorkspace              folder containing the cost rasters
# 5: ExtraRadius                specifies the extra margin to add to the distance to the next obs pt for the calculation of least-cost paths
# 6: VegCov_r                   raster of vegetation cover (for gap calculation)
# 7: GapVal                     value of VegCov_r representing the gap substrate type (barrier)
# 8: OutputWorkspace            folder where the results will be output
# 9: Debug                      debug mode (Yes/No)
# 10: FROMTO                    e-mail address to send notification once script is finished
# 11: HOST                      smpt server to send notification email

# Import system modules
import sys, string, os, arcgisscripting, random, time, math, glob, smtplib
from time import time, localtime, strftime # for date and time string functions for filenames

# Create the Geoprocessor object
gp = arcgisscripting.create()


#SNAP EXTENT TO RASTER: Returns a xMin, yMin, xMax, yMax extent snapped to the cell allignment of a raster"
def snapExtentToRaster(inputExtent, snapRaster):
    "Returns a xMin, yMin, xMax, yMax extent snapped to the cell allignment of a raster"
    if gp.exists(snapRaster) == 1: #Checks to see if the given snapRaster exists
        if string.lower(gp.describe(snapRaster).DatasetType) in ["rasterdataset","rasterband"]: #snapRaster must be a raster or rasterband        
            xMinInput = float(inputExtent.split()[0])
            yMinInput = float(inputExtent.split()[1])
            xMaxInput = float(inputExtent.split()[2])
            yMaxInput = float(inputExtent.split()[3])
            dsc = gp.describe(snapRaster)
            try: #if it is a single band image...
                cellSize = float(dsc.meancellheight)
            except: #if it is a multiband image... use Band_1
                cellSize = float(gp.describe(snapRaster + "\\Band_1").meancellheight)
            xMinSnap = float(dsc.extent.split()[0])
            yMinSnap = float(dsc.extent.split()[1])
            xMaxSnap = float(dsc.extent.split()[2])
            yMaxSnap = float(dsc.extent.split()[3])
            #Calculates a modified xMinInput
            if xMinSnap < xMinInput:
                if divmod(abs(xMinInput - xMinSnap), cellSize)[1] / cellSize < .5:
                    xMinOutput = xMinSnap + divmod(abs(xMinInput - xMinSnap), cellSize)[0] * cellSize
                else:
                    xMinOutput = xMinSnap + cellSize + divmod(abs(xMinInput - xMinSnap), cellSize)[0] * cellSize
            else:
                if divmod(abs(xMinInput - xMinSnap), cellSize)[1] / cellSize < .5:
                    xMinOutput = xMinSnap - divmod(abs(xMinInput - xMinSnap), cellSize)[0] * cellSize
                else:
                    xMinOutput = xMinSnap - cellSize - divmod(abs(xMinInput - xMinSnap), cellSize)[0] * cellSize      
            #Calculates a modified yMinInput
            if yMinSnap < yMinInput:
                if divmod(abs(yMinInput - yMinSnap), cellSize)[1] / cellSize < .5:
                    yMinOutput = yMinSnap + divmod(abs(yMinInput - yMinSnap), cellSize)[0] * cellSize
                else:
                    yMinOutput = yMinSnap + cellSize + divmod(abs(yMinInput - yMinSnap), cellSize)[0] * cellSize
            else:
                if divmod(abs(yMinInput - yMinSnap), cellSize)[1] / cellSize < .5:
                    yMinOutput = yMinSnap - divmod(abs(yMinInput - yMinSnap), cellSize)[0] * cellSize
                else:
                    yMinOutput = yMinSnap - cellSize - divmod(abs(yMinInput - yMinSnap), cellSize)[0] * cellSize     
            #Calculates a modified xMaxInput
            if xMaxSnap < xMaxInput:
                if divmod(abs(xMaxInput - xMaxSnap), cellSize)[1] / cellSize < .5:
                    xMaxOutput = xMaxSnap + divmod(abs(xMaxInput - xMaxSnap), cellSize)[0] * cellSize
                else:
                    xMaxOutput = xMaxSnap + cellSize + divmod(abs(xMaxInput - xMaxSnap), cellSize)[0] * cellSize
            else:
                if divmod(abs(xMaxInput - xMaxSnap), cellSize)[1] / cellSize < .5:
                    xMaxOutput = xMaxSnap - divmod(abs(xMaxInput - xMaxSnap), cellSize)[0] * cellSize
                else:
                    xMaxOutput = xMaxSnap - cellSize - divmod(abs(xMaxInput - xMaxSnap), cellSize)[0] * cellSize
            #Calculates a modified yMaxInput
            if yMaxSnap < yMaxInput:
                if divmod(abs(yMaxInput - yMaxSnap), cellSize)[1] / cellSize < .5:
                    yMaxOutput = yMaxSnap + divmod(abs(yMaxInput - yMaxSnap), cellSize)[0] * cellSize
                else:
                    yMaxOutput = yMaxSnap + cellSize + divmod(abs(yMaxInput - yMaxSnap), cellSize)[0] * cellSize
            else:
                if divmod(abs(yMaxInput - yMaxSnap), cellSize)[1] / cellSize < .5:
                    yMaxOutput = yMaxSnap - divmod(abs(yMaxInput - yMaxSnap), cellSize)[0] * cellSize
                else:
                    yMaxOutput = yMaxSnap - cellSize - divmod(abs(yMaxInput - yMaxSnap), cellSize)[0] * cellSize     
            #Returns the entire modified extent
            return str(xMinOutput) + " " + str(yMinOutput) + " " + str(xMaxOutput) + " " + str(yMaxOutput)
        else:
            print "ERROR: " + snapRaster + " is not a rasterdataset or a rasterband!"
    else:
        print "ERROR: " + snapRaster + " does not exist!"

	
try:
	# Set the necessary product code
	gp.SetProduct("ArcInfo")

	# Check out license
	gp.CheckOutExtension("spatial")

	gp.Toolbox = "lr"
	gp.Toolbox = "sa"
	gp.Toolbox = "conversion"
	gp.Toolbox = "management"
	gp.Toolbox = "analysis"

	gp.OverwriteOutput=1
	gp.AddWarning(" WARNING! Overwrite ON!")

	# Script arguments...
	Indiv_AllPoints = sys.argv[1] # One shapefile, with observed dispersal points; can contain several individuals
	IndivIDField = sys.argv[2]
	PtField = sys.argv[3]
	if PtField == "FID":
		gp.AddWarning("WARNING: resuming might not be possible with FID as point field ID")
	CostWorkspace = sys.argv[4] 
	ExtraRadius = int(sys.argv[5]) ##1000
	VegCov_r = sys.argv[6]
	GapVal = int(sys.argv[7])
	OutputWorkspace = sys.argv[8]
	Debug = sys.argv[9]
	FROMTO = sys.argv[10]
	HOST = sys.argv[11]
	if Debug=="true":
		gp.AddWarning("... "+str(len(sys.argv)) + " arguments called")
except:
	message = "Problem in very beginning!" + "\n" + gp.GetMessages()
	gp.AddError(message)
	sys.exit(2)

try:
	email_success = string.join(("From: %s" % FROMTO, "To: %s" % FROMTO, "Subject: [Python script automatic message] ArcGIS script execution completed successfully!!!", "", "ArcGIS script execution completed successfully!"), "\r\n")
	email_failure = string.join(("From: %s" % FROMTO, "To: %s" % FROMTO, "Subject: [Python script automatic message] ArcGIS script execution failed!!!", "", "ArcGIS script execution failed!!!"), "\r\n")

	# Check for existence of coordinates fields and create them if necessary
	fieldlist = gp.ListFields(Indiv_AllPoints,"POINT_X")
	fieldlist.reset()
	field = fieldlist.Next()
	if not field:
		gp.addxy_management(Indiv_AllPoints)
		gp.AddWarning("\n  Coordinates fields did not exist - Created them (fields POINT_X and POINT_Y)...\n")
	del fieldlist
	
	# Create log file
	OutFile = open(OutputWorkspace + "\\ExecutionLog_" + strftime('%Y%m%d_%H%M') + ".txt", "a")
	OutFile.writelines("Script execution started at " + strftime('%c') + "\n\n")
	OutFile.writelines(str(sys.argv) + "\n\n" + str(len(sys.argv)) + " arguments called" + "\n")
	OutFile.writelines("***********************************************************************************\n\n")
	if Debug=="true":
		message = "... Log file created in " + OutputWorkspace
		gp.AddWarning(message)
		OutFile.writelines(strftime('%c - ') + message + "\n\n")

	def AddMess (message):
		gp.AddWarning(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")
	def AddErr (message):
		gp.AddError(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")
		
	# Various global variables and paths
	GlobalExtent = gp.describe(VegCov_r).extent
	CellSize = gp.describe(VegCov_r).MeanCellWidth
	temppath_ = "TempDir_" + strftime('%Y%m%d_%H%M')
	if Debug=="true":
		AddMess("... Creating temp folder: " + temppath_)
	gp.CreateFolder_management(OutputWorkspace, temppath_)
	temppath = OutputWorkspace + "\\" + temppath_
	CostDist = temppath + "\\CostDist"
	Backlink = temppath + "\\Backlink"
	CostPath = temppath + "\\CostPath"
	CostPath2 = temppath + "\\CostPath2"
	###LCPaths_All = OutputWorkspace + "\\LCPaths_all.shp"

	#  Check if output table already exists (resuming) or not (then create it)
	gp.Workspace = OutputWorkspace
	inTables = glob.glob(OutputWorkspace.replace("\\","/") + "/Output_LCPaths*.dbf")
	Ntables = len(inTables)
	if Ntables==0:
		outputtable = "Output_LCPaths_" + strftime('%Y%m%d_%H%M') + ".dbf"
		if Debug=="true":
			AddMess("... Creating output table: " + outputtable)
		gp.CreateTable_management(OutputWorkspace, outputtable)
		if Debug=="true":
			AddMess("... Adding fields to output table")
		gp.AddField_management(outputtable,"INDIV","TEXT","","","10")
		gp.AddField_management(outputtable,"STARTPT","long")
		gp.AddField_management(outputtable,"ENDPT","long")
		gp.AddField_management(outputtable,"ANGLE","double")
		gp.DeleteField_management(outputtable,"Field1") # added when created table
		resuming = 0
	else:
		message = "  Found " + str(Ntables) + " tables Output_LCPaths_*.dbf in output workspace"
		if Ntables > 1:
			message = message + "\n  Warning! More than one output table in folder. Will use first one found."
		AddMess(message)
		outputtable = inTables[Ntables-1].replace("/","\\")
		AddMess("Found previous output table...\n   ...using " + outputtable + " for output")
		resuming = 1

	# Determine situation (new or resumed points, new or resumed cost sets,) and create necessary fields
	# All cost sets have to be together in the same folder with no other rasters in it.
	gp.Workspace = CostWorkspace 
	CostRasters1 = gp.ListRasters("*")
	CostRasters1.reset()
	CostRast1 = CostRasters1.Next()
	Nprevcostsets = 0
	Ncurrcostsets = 0
	Nnewcostsets = 0
	newcostsets = 0
	resumingnewcostsets = 0
	resumingnewcostsetsN = 0
	firstCStoprocess = 1
	csN = 0
	if resuming==1: #  output table found
		while CostRast1: # nb of current cost sets based on nb of rasters in cost set folders
			Ncurrcostsets = Ncurrcostsets + 1
			CostRast1 = CostRasters1.Next()
		if Debug=="true":
			AddMess("currently " + str(Ncurrcostsets) + " cost sets")
		fieldlist = gp.ListFields(outputtable,"PathL_*")
		fieldlist.reset()
		field = fieldlist.Next()
		while field: # nb of previous cost sets  based on nb of PathL_* fields in output table
			Nprevcostsets = Nprevcostsets + 1
			field  = fieldlist.Next()
		del fieldlist
		if Debug=="true":
			AddMess("... previously " + str(Nprevcostsets) + " cost sets")
		Nnewcostsets = Ncurrcostsets - Nprevcostsets
		if Debug=="true":
			AddMess("... " + str(Nnewcostsets) + " new cost set(s)")
		newcostsets = 0
		if Nnewcostsets<0:
			AddErr("Less cost sets now than in previous run. Cannot continue. Leave previous cost sets in same folder as before or add new ones to them.")
			del CostRasters
			sys.exit(2)
		if Nnewcostsets>0:
			firstCStoprocess = Nprevcostsets + 1
			AddMess("Will process all cost sets from #" + str(firstCStoprocess))
			newcostsets = 1
			AddMess(str(Nnewcostsets) + " new cost set(s) detected while resuming - will be processed.")
			CostRasters1.reset()
			CostRast1 = CostRasters1.Next()
			for i in range(1,firstCStoprocess):
				CostRast1 = CostRasters1.Next() # move cost set cursor to first new cost set
			costsetN = Nprevcostsets
			while costsetN < Ncurrcostsets: # create additional cost set fields in outputtable
				costsetN = costsetN + 1
				AddMess("New cost set " + str(costsetN) + ": " + CostRast1)
				gp.Workspace = OutputWorkspace
				fieldname = "PATHL_C" + str(costsetN) 
				gp.AddField_management(outputtable,fieldname,"double")  # Path length
				fieldname = "PATHC_C" + str(costsetN) 
				gp.AddField_management(outputtable,fieldname,"double")  # Path cost
				fieldname = "MAXGAP_C" + str(costsetN) 
				gp.AddField_management(outputtable,fieldname,"double") # Max gap
				gp.Workspace = CostWorkspace
				CostRast1 = CostRasters1.Next() # move cost set cursor to first new cost set
			if Debug=="true":
				AddMess("... Fields for new cost sets created")
		if Nnewcostsets == 0: # check if resuming new cost sets
			TestCur = gp.SearchCursor(outputtable)
			TestCur.reset()
			TestRow = TestCur.Next()
			while TestRow:
				for csN in range(1,Nprevcostsets+1):
					if not TestRow.GetValue("PATHL_C" + str(csN)):
						if not resumingnewcostsets: # first empty cell found
							firstCStoprocess = csN
							resumInd = TestRow.INDIV
							resumSPt = TestRow.STARTPT
							resumEPt = TestRow.ENDPT
							resumingnewcostsets = 1
				TestRow = TestCur.Next()
			resumingnewcostsetsN = Nprevcostsets - firstCStoprocess + 1
			if resumingnewcostsets:
				AddMess(str(resumingnewcostsetsN) + " new cost sets to be resumed. From " + str(resumInd) + " - Start pt: " + str(resumSPt))
			del TestRow, TestCur
	else:  # if not resuming (no output table in output folder)
		costsetN=0
		newcostsets=0
		if Debug=="true":
			AddMess("... Adding cost fields to output table")
		while CostRast1: # Adds fields according to number of cost sets
			costsetN=costsetN+1
			AddMess("Cost set " + str(costsetN) + ": " + CostRast1)
			gp.Workspace = OutputWorkspace
			fieldname = "PATHL_C" + str(costsetN) 
			gp.AddField_management(outputtable,fieldname,"double")  # Path length
			fieldname = "PATHC_C" + str(costsetN) 
			gp.AddField_management(outputtable,fieldname,"double")  # Path cost
			fieldname = "MAXGAP_C" + str(costsetN) 
			gp.AddField_management(outputtable,fieldname,"double") # Max gap
			gp.Workspace = CostWorkspace
			CostRast1 = CostRasters1.Next()
	del CostRasters1

except:
	if FROMTO != "":
		server = smtplib.SMTP(HOST)
		server.sendmail(FROMTO, FROMTO, email_failure)
		server.quit()
	AddErr("Problem in beginning!" + "\n" + gp.GetMessages())
	OutFile.close()
	del CostRasters1, fieldlist, TestCur
	sys.exit(2)

	
# Preparation for loop on dispersal points
if Debug=="true":
	AddMess("... Starting loop in observation points table")
ObsCur = gp.SearchCursor(Indiv_AllPoints)
ObsRow = ObsCur.Next()
NextObsCur = gp.SearchCursor(Indiv_AllPoints)
NextObsRow = NextObsCur.Next()
NextObsRow = NextObsCur.Next()
resumingindiv = 0
if resuming==1 and Nnewcostsets==0: 
	if ObsRow.GetValue(IndivIDField) != NextObsRow.GetValue(IndivIDField): 
		AddMess("Resuming at a new individual")
		resumingindiv = 0
		ObsRow = ObsCur.Next()
		NextObsRow = NextObsCur.Next()
	else:
		AddMess("Resuming at previous individual")
		resumingindiv = 1
		prevX = ObsRow.POINT_X
		prevY = ObsRow.POINT_Y
		ObsRow = ObsCur.Next()
		NextObsRow = NextObsCur.Next()
			
# ------------------------------------------------------------------------------------------------------------------------------------------------------------
# LOOP WITHIN TABLE OF OBSERVED POINTS
# ------------------------------------------------------------------------------------------------------------------------------------------------------------
while NextObsRow: # start of individual
	try:
		# Initialisation for each individual
		# Creates Individual folder, extracts individual points, and creates feature classes
		IndivID = ObsRow.GetValue(IndivIDField)
		IndivID2 = IndivID.replace('-','')
		AddMess("\n==================================== " + str(IndivID) + " ========================================")
		OutputWorkspaceIndiv = OutputWorkspace + "\\" + IndivID2

		if not gp.Exists(OutputWorkspaceIndiv):
			if Debug=="true":
				AddMess("... Creating individual folder")
			gp.CreateFolder_management(OutputWorkspace, IndivID2)
		else:
			if Debug=="true":
				AddMess("Individual folder " + IndivID2 + " already exists - skip creation")

		indivptN = 0

		if resumingindiv == 1:
			indivptN = 1
			resumingindiv = 0 
	except:
		if FROMTO != "":
			server = smtplib.SMTP(HOST)
			server.sendmail(FROMTO, FROMTO, email_failure)
			server.quit()
		AddErr("PROBLEM in start of loop within table of observed points!\n" + gp.GetMessages())
		OutFile.close()
		del ObsCur, NextObsCur
		sys.exit(2)
	  

	# ----------------------------------------------------------------------------------------------------------------------------------------------------
	# LOOP WITHIN 1 INDIVIDUAL - start for each obs point (skip null distances), extract starting point and end point 
	# ----------------------------------------------------------------------------------------------------------------------------------------------------
	# 1- Loop through obs pts, stop when dist to next pt (dtnp) >0 within the same individual.
	# 2- Select start pt and end pt.
	# 3- Calculate Least cost path for each dispersal step.
	# 4- Repeat for each obs pt for the individual

	while NextObsRow and NextObsRow.GetValue(IndivIDField)==IndivID : # Loop within individual
		try:
			indivptN = indivptN + 1
			PathLength = 0.0
			# Skip points where no movement was recorded
			while NextObsRow and (pow(ObsRow.POINT_X-NextObsRow.POINT_X,2)+pow(ObsRow.POINT_Y-NextObsRow.POINT_Y,2))==0 and NextObsRow.GetValue(IndivIDField)==IndivID:
				if Debug=="true":
					AddMess(str(ObsRow.FID2)+" -> " + str(NextObsRow.FID2) + " skipped.")
				ObsRow = ObsCur.Next()
				NextObsRow = NextObsCur.Next()
				if not ObsRow:
					AddErr("big pb1")
				if not NextObsRow:
					AddErr("big pb2")

			if not NextObsRow:
				break
				AddMess("break1")

			if NextObsRow.GetValue(IndivIDField) != IndivID:
				break
				AddMess("break2")

			if indivptN == 1:
				prevX = ObsRow.POINT_X
				prevY = ObsRow.POINT_Y

			currX=ObsRow.POINT_X
			currY=ObsRow.POINT_Y
			currID=ObsRow.GetValue(PtField)

			nextX=NextObsRow.POINT_X
			nextY=NextObsRow.POINT_Y
			nextID=NextObsRow.GetValue(PtField)

			DistToNext = 0.0
			DistToNext = pow(pow(currX-nextX,2)+pow(currY-nextY,2),.5)

			AddMess("   === " + str(IndivID) + " - #" + str(indivptN) + " - From " + str(currID) + " to " + str(nextID) + " - Distance " + str(round(DistToNext)) + " ===")

			# Calculate turning angle
			dPO = pow(pow(prevX-currX,2)+pow(prevY-currY,2),0.5)
			if indivptN > 1:
				dOS = pow(pow(currX-nextX,2)+pow(currY-nextY,2),0.5)
				dPS = pow(pow(prevX-nextX,2)+pow(prevY-nextY,2),0.5)
				CosTheta = (pow(dPO,2)+pow(dOS,2)-pow(dPS,2))/(2*dPO*dOS)
				Theta = 0.0
				Theta = math.degrees(math.acos(CosTheta))
				Alpha = 180-Theta
			else:
				Alpha = 999  # if no previous pt

			# local variables, unique to each pair of points
			Indiv_Sel_source = temppath + "\\source_pt.shp" 
			Indiv_Sel_dest = temppath + "\\destination_pt.shp"
			VegCovPolyg = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_VegCovPolyg.shp"
			VegCovDiss = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_VegCovPDiss.shp"
			PathCost = 0.0

			# Select start and end points
			gp.Select_analysis(Indiv_AllPoints, Indiv_Sel_source, "\""+PtField+"\"="+str(int(currID)))
			gp.MakeFeatureLayer_management(Indiv_Sel_source, "SourcePt_lyr")
			gp.Select_analysis(Indiv_AllPoints, Indiv_Sel_dest, "\""+PtField+"\"="+str(int(nextID)))
			gp.MakeFeatureLayer_management(Indiv_Sel_dest, "DestPt_lyr")
			if Debug=="true":
				AddMess("... Start and end points selected")
		except:
			if FROMTO != "":
				server = smtplib.SMTP(HOST)
				server.sendmail(FROMTO, FROMTO, email_failure)
				server.quit()
			AddErr("PROBLEM!\n" + gp.GetMessages())
			OutFile.close()
			del ObsCur, NextObsCur
			sys.exit(2)

		try:    # Start Extent calculation, land conversion and dissolve
			# Determine extent for all the random points for each obs pt,
			Xmin = int(min(currX,nextX)-ExtraRadius)
			Xmin = int(Xmin/15) * 15 + 5    # snap coordinates to veg cov raster...
			Xmax = int(max(currX,nextX)+ExtraRadius)
			Xmax = int(Xmax/15) * 15 + 5
			Ymin = int(min(currY,nextY)-ExtraRadius)
			Ymin = int(Ymin/15) * 15 - 5
			Ymax = int(max(currY,nextY)+ExtraRadius)
			Ymax = int(Ymax/15) * 15 - 5
			CalcExtent = str(Xmin) + " " + str(Ymin) + " " + str(Xmax) + " " + str(Ymax)    #square centered on source point, dimension depends on Dist2NextP + user-defined extra
			CalcExtent = snapExtentToRaster(CalcExtent, VegCov_r)
			if Debug=="true":
				AddMess("... Extent= " + CalcExtent)

			# Convert vegetation cover (raster) into polygons using extent
			gp.Extent = CalcExtent
			if not gp.Exists(VegCovPolyg):
				gp.RasterToPolygon_conversion(VegCov_r, VegCovPolyg, "NO_SIMPLIFY")
				gp.Dissolve_management(VegCovPolyg, VegCovDiss, "GRIDCODE")
				if Debug=="true":
					AddMess("... Finished conversion and dissolution of landscape from raster to polygons")
			else:
				if Debug=="true":
					AddMess("Polygon land cover already exists")

		except: # End   Extent calculation, land conversion and dissolve
			if FROMTO != "":
				server = smtplib.SMTP(HOST)
				server.sendmail(FROMTO, FROMTO, email_failure)
				server.quit()
			AddErr("Problem before LC loop!\n" + gp.GetMessages())
			OutFile.close()
			del ObsCur, NextObsCur
			sys.exit(2)

		#  List cost rasters and place cursor on first needed raster
		gp.Workspace = CostWorkspace 
		CostRasters = gp.ListRasters("*")
		CostRasters.reset()
		CostRast = CostRasters.Next()
		if firstCStoprocess>1:
			for i in range(1,firstCStoprocess):
				CostRast = CostRasters.Next() # move cost set cursor to first new cost set
			costsetN = Nprevcostsets # will be increased by 1 at start of CS loop
			if resumingnewcostsets:
				costsetN = firstCStoprocess - 1
		else:
			costsetN = 0

		# Test for existence of dispersal path in output table if updating -  skip point if not there
		if firstCStoprocess>1:
			condtxt = "\"INDIV\"= '" + IndivID + "' AND \"STARTPT\"=" + str(currID)
			testrows = gp.SearchCursor(outputtable,condtxt)
			testrow = testrows.next()
			if not testrow:
				AddMess("path not found, skip...")
				ObsRow = ObsCur.Next()
				NextObsRow = NextObsCur.Next()
				del testrows
				continue
			del testrows


		# ---------------------------------------------------------------------------------------------------------------------------------------------------------------
		# LOOP WITHIN FOLDER OF COST RASTERS
		# ---------------------------------------------------------------------------------------------------------------------------------------------------------------
		while CostRast:
			try:    
				# Start Preparation to least-cost path
				SameCell = False
				gp.Extent = CalcExtent
				costsetN = costsetN + 1
				if Debug=="true":
					AddMess("... using cost set " + str(costsetN) + ": " + CostRast)
				gp.Workspace = OutputWorkspace

				# Prepare output row (new row or update depending on situation)
				if firstCStoprocess>1: # if new cost sets or resuming new cost sets
					if costsetN == firstCStoprocess:
						condtxt = "\"INDIV\"= '" + IndivID + "' AND \"STARTPT\"=" + str(currID)
						OutputRows = gp.UpdateCursor(outputtable, condtxt)
						OutputRow = OutputRows.next()
				else: 
					if costsetN == 1: # new line for obs pt (different cost sets in different fields)
						OutputRows = gp.InsertCursor(outputtable)
						OutputRow = OutputRows.NewRow()
						OutputRow.INDIV = IndivID
						OutputRow.STARTPT = currID
						OutputRow.ENDPT = nextID
				if not gp.Exists(OutputWorkspaceIndiv + "\\CostSet" + str(costsetN)):
					if Debug=="true":
						AddMess("... Creating Cost folder")
					gp.CreateFolder_management(OutputWorkspaceIndiv, "CostSet" + str(costsetN))

				PathLine = OutputWorkspaceIndiv + "\\CostSet" + str(costsetN) + "\\" + IndivID2 + "_StartPt" + str(currID) + "_EndPt" + str(nextID) + "_CPLine.shp"
				SplittedPath = OutputWorkspaceIndiv + "\\CostSet" + str(costsetN) + "\\" + IndivID2 + "_StartPt" + str(currID) + "_EndPt" + str(nextID) + "_PathSegments.shp"
				SplittedPathAll = OutputWorkspaceIndiv + "\\CostSet" + str(costsetN) + "\\" + IndivID2 + "_StartPt" + str(currID) + "_EndPt" + str(nextID) + "_PathSingleSegments.shp"
				AllPaths = OutputWorkspace + "\\AllPaths.shp"
				PathCost = 0.0
				gp.Workspace = CostWorkspace
			except: # End   Preparation to least-cost path
				if FROMTO != "":
					server = smtplib.SMTP(HOST)
					server.sendmail(FROMTO, FROMTO, email_failure)
					server.quit()
				AddErr("Problem in preparation to least-cost path!\n" + gp.GetMessages())
				OutFile.close()
				del ObsCur, NextObsCur, CostRasters, OutputRows
				sys.exit(2)
				
			try:    # Start Calculate Least-cost path
				# Cost Distance calculation
				gp.CostDistance_sa(Indiv_Sel_source, CostRast, CostDist, "", Backlink)
				if Debug=="true":
					AddMess("... Finished cost distance")

				# Least-cost path
				gp.CostPath_sa(Indiv_Sel_dest, CostDist, Backlink, CostPath, "EACH_CELL", "")
				if Debug=="true":
					AddMess("... Finished cost path")

				# Extract Path cost value from raster
				gp.ZonalStatisticsAsTable_sa(Indiv_Sel_dest, IndivIDField, CostDist, temppath + "\\temp_table.dbf", "DATA")
				CostP_cur = gp.SearchCursor(temppath + "\\temp_table.dbf")
				CostP_row = CostP_cur.Next()
				PathCost = CostP_row.GetValue("MAX")
				del CostP_cur
				if Debug=="true":
					AddMess("... Extracted path cost ("+str(round(PathCost,2))+")")
				OutputRow.SetValue("PATHC_C"+ str(costsetN), PathCost)
				gp.Reclassify_sa(CostPath, "VALUE", "1 1 1;3 3 1", CostPath2, "DATA")

			except: # End   Calculate Least-cost path
				if FROMTO != "":
					server = smtplib.SMTP(HOST)
					server.sendmail(FROMTO, FROMTO, email_failure)
					server.quit()
				AddErr("Failed in processing least-cost path...!!!\n" + gp.GetMessages())
				OutFile.close()
				del ObsCur, NextObsCur, CostRasters, OutputRows, CostP_cur
				sys.exit(2)

			try:
				# Convert rasterized path to polyline
				gp.Workspace = OutputWorkspace
				gp.RasterToPolyline_conversion(CostPath2, PathLine, "ZERO", "0", "NO_SIMPLIFY", "VALUE")  
				if Debug=="true":
					AddMess("... Finished conversion path raster to polyline")
				gp.Extent = GlobalExtent
			except:
				AddMess("      Warning! Start and end points in same raster cell -> no path line")
				SameCell = True
				GapMax_path = 0.0
				TotalPathLength = CellSize
				gp.Extent = GlobalExtent

			try:    # Start splitting path, add and populate fields of SplittedPathAll
				# Split least-cost path according to vegetation, add attributes (indiv, pt nb, distance, cost) and append to indiv shapefile
				if SameCell == False:
					if Debug=="true":
						AddMess("... Splitting path")
					# Intersect path line with vegetation cover (polygon)
					gp.Identity_analysis(PathLine, VegCovDiss, SplittedPath)  # had problems with: gp.Intersect_analysis(VegCovDiss+";"+PathLine,SplittedPath,"ALL","","LINE")
					gp.MultipartToSinglepart_management(SplittedPath, SplittedPathAll)

					# Add attributes fields
					gp.AddField_management(SplittedPathAll, "Indiv", "TEXT", "", "", "6")
					gp.AddField_management(SplittedPathAll, "PathID", "TEXT", "", "", "6")
					gp.AddField_management(SplittedPathAll, "StartPt_ID", "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(SplittedPathAll, "Segm_Nb", "LONG", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(SplittedPathAll, "Len", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(SplittedPathAll, "Cost", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(SplittedPathAll, "CostSet", "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

					# Add path specific attributes
					gp.CalculateField_management(SplittedPathAll, "Indiv", str(IndivID2))
					gp.CalculateField_management(SplittedPathAll, "PathID", IndivID2 + "_" + str(int(currID)) + "to" + str(int(nextID)))
					gp.CalculateField_management(SplittedPathAll, "StartPt_ID", currID)
					##gp.CalculateField_management(SplittedPathAll, "ChoicePtN", choiceptN)
					gp.CalculateField_management(SplittedPathAll, "CostSet", costsetN)
					gp.CalculateField_management(SplittedPathAll, "Cost", PathCost)

					# Add segment specific attributes and record length of biggest gap
					if Debug=="true":
						AddMess("... Calculating path length and max distance across barrier")
					upd_cur = gp.UpdateCursor(SplittedPathAll)
					upd_row = upd_cur.Next()
					segN = 0
					GapMax_path = 0.0
					TotalPathLength = 0.0
					while upd_row:
						segN = segN + 1
						PathLength = upd_row.Shape.Length
						TotalPathLength = TotalPathLength + PathLength
						upd_row.SetValue("Len", PathLength)
						if (PathLength > GapMax_path) and (upd_row.GRIDCODE==GapVal):  # Update value of biggest gap in the path if new record
							GapMax_path = PathLength
						upd_row.Segm_Nb = segN
						upd_cur.UpdateRow(upd_row)
						upd_row = upd_cur.Next()
					del upd_cur
					OutputRow.SetValue("PATHL_C"+ str(costsetN), TotalPathLength)
					OutputRow.SetValue("MAXGAP_C"+ str(costsetN), GapMax_path)
			except: # End   splitting path, add and populate fields of SplittedPathAll
				if FROMTO != "":
					server = smtplib.SMTP(HOST)
					server.sendmail(FROMTO, FROMTO, email_failure)
					server.quit()
				AddErr("Error in splitting path section!\n" + gp.GetMessages())
				OutFile.close()
				del ObsCur, NextObsCur, CostRasters, OutputRows, upd_cur
				sys.exit(2)

			try:    # Start add and populate fields in PathLine. and append it to AllPaths
				if SameCell == False:
					gp.AddField_management(PathLine, "Indiv", "TEXT", "", "", "6")
					gp.AddField_management(PathLine, "StartPtID", "LONG", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "EndPtID", "LONG", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "PathID", "TEXT", "", "", "")
					gp.AddField_management(PathLine, "Start_X", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "Start_Y", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "End_X", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "End_Y", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "PathLen", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "PathCost", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "MaxGap", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "Angle", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
					gp.AddField_management(PathLine, "CostSet", "short")
					gp.AddField_management(PathLine, "CS_name", "TEXT", "50")

					UpdRows = gp.UpdateCursor(PathLine)
					UpdRow = UpdRows.Next()
					UpdRow.Indiv = IndivID2
					UpdRow.StartPtID = currID
					UpdRow.EndPtID = nextID
					UpdRow.PathID = IndivID2 + "_" + str(int(currID)) + "to" + str(int(nextID))
					UpdRow.Start_X = currX
					UpdRow.Start_Y = currY
					UpdRow.End_X = nextX 
					UpdRow.End_Y = nextY 
					UpdRow.CostSet = costsetN
					UpdRow.PathLen = TotalPathLength
					UpdRow.PathCost = PathCost
					UpdRow.MaxGap = GapMax_path
					UpdRow.Angle = Alpha 
					UpdRow.CS_name = CostRast
					UpdRows.UpdateRow(UpdRow)
					del UpdRows

					OutputRow.Angle = Alpha 

					if Debug=="true":
						AddMess("... Finished adding attributes to single path")

					if not gp.Exists(OutputWorkspace + "\\AllPaths.shp"):
						gp.CreateFeatureclass_management(OutputWorkspace, "AllPaths.shp", "POLYLINE", PathLine, "DISABLED", "DISABLED", "PROJCS['GD_1949_New_Zealand_Map_Grid',GEOGCS['GCS_New_Zealand_1949',DATUM['D_New_Zealand_1949',SPHEROID['International_1924',6378388.0,297.0]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['New_Zealand_Map_Grid'],PARAMETER['False_Easting',2510000.0],PARAMETER['False_Northing',6023150.0],PARAMETER['Longitude_Of_Origin',173.0],PARAMETER['Latitude_Of_Origin',-41.0],UNIT['Meter',1.0]];-10000.000000 -10000.000000 100000.000000;0.000000 100000.000000;0.000000 100000.000000", "", "1000", "0", "0")
					gp.Append_management(PathLine, AllPaths, "NO_TEST")

				AddMess("         Cost Set " + str(costsetN) + " - Cost: " + str(round(PathCost,1)) + " - Length: " + str(round(TotalPathLength,1)) + " - Max gap: " + str(round(GapMax_path,1)) + " - Angle: " + str(round(Alpha,1))) ##Angles[choiceptN-1],1)))
			except: # End   add and populate fields in PathLine. and append it to AllPaths
				if FROMTO != "":
					server = smtplib.SMTP(HOST)
					server.sendmail(FROMTO, FROMTO, email_failure)
					server.quit()
				AddErr("Error in field creation and calculation in PathLine!\n" + gp.GetMessages())
				OutFile.close()
				del ObsCur, NextObsCur, CostRasters, OutputRows, UpdRows
				sys.exit(2)

			gp.Workspace = CostWorkspace 
			CostRast = CostRasters.Next()
			# Go to next cost raster

		try:
			gp.AddMessage("finished loop with cost raster folder")
			if firstCStoprocess == 1:
				OutputRows.InsertRow(OutputRow)
			else:
				OutputRows.UpdateRow(OutputRow)
			prevX = currX
			prevY = currY
			ObsRow = ObsCur.Next()
			NextObsRow = NextObsCur.Next()
			del OutputRows
		except:
			if FROMTO != "":
				server = smtplib.SMTP(HOST)
				server.sendmail(FROMTO, FROMTO, email_failure)
				server.quit()
			AddErr("Problem at the end of loop within 1 individual\n" + gp.GetMessages())
			OutFile.close()
			sys.exit(2)
		# Go to next point within individual

	gp.AddMessage("finished loop within individual")
	if NextObsRow and (NextObsRow.GetValue(IndivIDField) != IndivID) and (ObsRow.GetValue(IndivIDField)==IndivID):
		ObsRow = ObsCur.Next()
		NextObsRow = NextObsCur.Next()
	# End of loop within obs table

# End of obs pts

if FROMTO != "":
	server = smtplib.SMTP(HOST)
	server.sendmail(FROMTO, FROMTO, email_success)
	server.quit()
del ObsCur, NextObsCur
AddMess(strftime('%c') + ": Script finished successfully!!!")
OutFile.close()

del ExtraRadius, VegCov_r, OutputWorkspace, Indiv_AllPoints, IndivID, IndivID2, indivptN, PathLength, currID, nextID
del Indiv_Sel_source, CostDist, Backlink, CostPath2, PathLine, VegCovPolyg, VegCovDiss, SplittedPath, SplittedPathAll
del PathCost, currX, nextX, currY, nextY, DistToNext, Xmin, Xmax, Ymin, Ymax, CalcExtent
