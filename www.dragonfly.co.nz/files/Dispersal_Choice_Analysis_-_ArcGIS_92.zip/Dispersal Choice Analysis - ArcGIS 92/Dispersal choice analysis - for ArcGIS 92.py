# ---------------------------------------------------------------------------
# Dispersal choice analysis - for ArcGIS 92.py
# Created on: Wed Feb 15 2006
# by Yvan Richard (y.richard@massey.ac.nz - http://www.massey.ac.nz/~yrichard)
# ---------------------------------------------------------------------------
# Last updated: 6-Mar-2009


# REQUIREMENTS:
# Every points in the observed points shapefile should have an index of the individual and a point index (indicating the chronological order)
# and should be sorted by individual and time
# The input points can be in different shapefiles, as long as the points of one individual are in the same one.
# Several individuals can be placed in the same shapefile.

# TO DO:

# ARGUMENTS:
# 1: Indiv_AllPoints           shapefile with individual and point ID fields
# 2: IndivIDField              name of the individual ID field
# 3: PtField                   name of the point ID field (of Indiv_AllPoints)
# 4: RndPts                    shapefile with random alternative points
# 5: RndPtIDField              name of the point ID field (of RndPts)
# 6: DonutSize                 size of the doughnut to select alternative points at the same distance than the next obs pt
# 7: NSelPts                   number of alternative points to be selected
# 8: CostWorkspace             folder where the cost rasters are located
# 9: ExtraRadius              specifies the extra margin to add to the distance to the next obs pt for the calculation of least-cost paths
# 10: VegCov_r                 any raster from which extent and cell size will be determined
# 11: OutputWorkspace          folder where the results will be output
# 12: Debug                    Debug mode (Yes/No)
# 13: FROMTO                   email address of user to be notified of errors or completion message once script finished
# 14: HOST                     SMTP server address


# Import system modules
import sys, string, os, arcgisscripting, random, time, math, glob
from time import time, localtime, strftime # for date and time string functions for filenames
# for email sending
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders
 

	
# Create the Geoprocessor object
gp = arcgisscripting.create()

try:
	# Set the necessary product code
	gp.SetProduct("ArcInfo")

	# Check out any necessary licenses
	gp.CheckOutExtension("spatial")

	gp.Toolbox = "lr"
	gp.Toolbox = "sa"
	gp.Toolbox = "conversion"
	gp.Toolbox = "management"
	gp.Toolbox = "analysis"

	gp.OverWriteOutput=1
	gp.AddWarning(" WARNING! Overwrite ON!")

	# Script arguments...
	Indiv_AllPoints = sys.argv[1] # One shapefile, with observed dispersal points; can contain several individuals
	IndivIDField = sys.argv[2]
	PtField = sys.argv[3]
	if PtField == "FID":
		gp.AddWarning("WARNING: resuming might not be possible with FID as point field ID")
	RndPts = sys.argv[4] # Point shapefile with random alternative points; one shapefile for all dispersal steps
	RndPtIDField = sys.argv[5]
	DonutSize = int(sys.argv[6]) ##200
	NSelPts = int(sys.argv[7]) ##10
	CostWorkspace = sys.argv[8] # Workspace with cost rasters in argument 10 set later on
	ExtraRadius = int(sys.argv[9]) # Used for clipping region encompassing alternative points for saving computation time ##1000
	VegCov_r = sys.argv[10]
	OutputWorkspace = sys.argv[11]
	Debug = sys.argv[12]
	FROMTO = sys.argv[13]
	HOST = sys.argv[14]
	if Debug=="true":
		gp.AddWarning("... "+str(len(sys.argv)) + " arguments called")
except:
	message = "Problem in very beginning!" + "\n" + gp.GetMessages()
	gp.AddError(message)
	sys.exit(2)

	
def sendMail(subject, files=[]):   # Function to send email once script is finished
    assert type(files)==list
    msg = MIMEMultipart()
    msg['From'] = FROMTO
    msg['To'] = FROMTO
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject
    msg.attach( MIMEText(subject) )

    for file in files:
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(file,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"'
                       % os.path.basename(file))
        msg.attach(part)

    smtp = smtplib.SMTP(HOST)
    smtp.sendmail(FROMTO, FROMTO, msg.as_string() )
    smtp.close()


try:
	email_success = string.join(("From: %s" % FROMTO, "To: %s" % FROMTO, "Subject: [Python script automatic message] ArcGIS script execution completed successfully!!!", "", "ArcGIS script execution completed successfully!"), "\r\n")
	email_failure = string.join(("From: %s" % FROMTO, "To: %s" % FROMTO, "Subject: [Python script automatic message] ArcGIS script execution failed!!!", "", "ArcGIS script execution failed!!!"), "\r\n")
	subject_success = "[Python script automatic message] ArcGIS script execution completed successfully!!!"
	subject_failure = "[Python script automatic message] ArcGIS script execution failed!!!"
	OutFile_name = OutputWorkspace + "\\ExecutionLog_" + strftime('%Y%m%d_%H%M') + ".txt"
	OutFile = open(OutFile_name, "a")
	OutFile.writelines("Script execution started at " + strftime('%c') + "\n\n")
	OutFile.writelines(str(sys.argv) + "\n\n" + str(len(sys.argv)) + " arguments called" + "\n")
	OutFile.writelines("***********************************************************************************\n\n")
	if Debug=="true":
		message = "... Log file created in " + OutputWorkspace
		gp.AddWarning(message)
		OutFile.writelines(strftime('%c - ') + message + "\n\n")

	GlobalExtent = gp.describe(VegCov_r).extent
	CellSize = gp.describe(VegCov_r).MeanCellWidth
	firstiteration = 1
	temppath_ = "TempDir_" + strftime('%Y%m%d_%H%M')
	if Debug=="true":
		message = "... Creating temp folder: " + temppath_
		gp.AddWarning(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")
	gp.CreateFolder_management(OutputWorkspace, temppath_)
	temppath = OutputWorkspace + "\\" + temppath_
	CostDist = temppath + "\\CostDist"
	Backlink = temppath + "\\Backlink"

	gp.Workspace = OutputWorkspace
	inTables = glob.glob(OutputWorkspace.replace("\\","/") + "/Global*.dbf")
	Ntables = len(inTables)
	if Debug=="true":
		message = "... " + str(Ntables) + " tables GlobalResults_*.dbf in output workspace"
		gp.AddWarning(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")

	if Ntables==0: # if no output table exists, then create from scratch
		outputtable = "GlobalResults_" + strftime('%Y%m%d_%H%M') + ".dbf"
		if Debug=="true":
			message = "... Creating output table: " + outputtable
			gp.AddWarning(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
		gp.CreateTable_management(OutputWorkspace, outputtable)
		if Debug=="true":
			message = "... Adding fields to output table"
			gp.AddWarning(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
		gp.AddField_management(outputtable,"Indiv","TEXT","","","10")
		gp.AddField_management(outputtable,"StartPt","long")
		gp.AddField_management(outputtable,"EndPt","long")
		gp.AddField_management(outputtable,"Choice","short")
		gp.AddField_management(outputtable,"MatchPt","short")
		gp.AddField_management(outputtable,"MatchID","long")
		gp.AddField_management(outputtable,"Angle","double")
		gp.DeleteField_management(outputtable,"Field1")
		resuming = 0
	else:  # if output table already exists (i.e. when resuming), then use it to append results
		outputtable = inTables[Ntables-1].replace("/","\\")
		message = "Found previous output table...\n   ...using " + outputtable + " for output"
		gp.AddWarning(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")
		resuming = 1

	# Create cost related fields depending on the number of cost sets
	# All cost sets have to be together in the same folder with no other rasters in it.
	gp.Workspace = CostWorkspace
	CostRasters1 = gp.ListRasters("*")
	CostRasters1.reset()
	CostRast1 = CostRasters1.Next()

	# Determine situation (new or resumed points, new or resumed cost sets,)
	Nprevcostsets = 0  # nb of cost sets previously run (based on nb of PATHC_* fields
	Ncurrcostsets = 0  # nb of cost sets in folder
	Nnewcostsets = 0
	newcostsets = 0
	resumingnewcostsets = 0
	resumingnewcostsetsN = 0
	firstCStoprocess = 1
	csN = 0
	if resuming==1: #  output table found
		while CostRast1: # nb of current cost sets based on nb of rasters in cost set folders
			Ncurrcostsets = Ncurrcostsets + 1
			CostRast1 = CostRasters1.Next()
		if Debug=="true":
			message = "currently " + str(Ncurrcostsets) + " cost sets"
			gp.AddWarning(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
		fieldlist = gp.ListFields(outputtable,"PATHC_*")
		fieldlist.reset()
		field = fieldlist.Next()
		while field: # nb of previous cost sets  based on nb of PathC_* fields in output table
			Nprevcostsets = Nprevcostsets + 1
			field  = fieldlist.Next()
		del fieldlist
		if Debug=="true":
			gp.AddWarning("... previously " + str(Nprevcostsets) + " cost sets")
		Nnewcostsets = Ncurrcostsets - Nprevcostsets
		if Debug=="true":
			message = "... " + str(Nnewcostsets) + " new cost set(s)"
			gp.AddWarning(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
		newcostsets = 0
		if Nnewcostsets<0:
			message = "Less cost sets now than in previous run. Cannot continue. Leave previous cost sets in same folder as before or add new ones to them."
			gp.AddError(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
			del CostRasters
			sys.exit(2)
		if Nnewcostsets>0:
			firstCStoprocess = Nprevcostsets + 1
			gp.AddMessage("Will process all cost sets from #" + str(firstCStoprocess))
			newcostsets = 1
			message = str(Nnewcostsets) + " new cost set(s) detected while resuming - will be processed."
			gp.AddMessage(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
			CostRasters1.reset()
			CostRast1 = CostRasters1.Next()
			for i in range(1,firstCStoprocess):
				CostRast1 = CostRasters1.Next() # move cost set cursor to first new cost set
			costsetN = Nprevcostsets
			while costsetN < Ncurrcostsets: # create additional cost set fields in outputtable
				costsetN = costsetN + 1
				message = "New cost set " + str(costsetN) + ": " + CostRast1
				gp.AddMessage(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
				gp.Workspace = OutputWorkspace
				fieldname = "PATHC_C" + str(costsetN)
				gp.AddField_management(outputtable,fieldname,"double")  # Path cost
				gp.Workspace = CostWorkspace
				CostRast1 = CostRasters1.Next() # move cost set cursor to first new cost set
			if Debug=="true":
				message = "... Field PATHC_C* for new cost sets created"
				gp.AddWarning(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
		if Nnewcostsets == 0: # check if resuming new cost sets
			TestCur = gp.SearchCursor(outputtable)
			TestCur.reset()
			TestRow = TestCur.Next()
			while TestRow:
				for csN in range(1,Nprevcostsets+1):
					if not TestRow.GetValue("PATHC_C" + str(csN)):
						if not resumingnewcostsets: # first empty cell found
							firstCStoprocess = csN
							resumInd = TestRow.INDIV
							resumSPt = TestRow.STARTPT
							resumEPt = TestRow.ENDPT
							resumMPt = TestRow.MATCHPT
							resumingnewcostsets = 1
				TestRow = TestCur.Next()
			resumingnewcostsetsN = Nprevcostsets - firstCStoprocess + 1
			if resumingnewcostsets:
				message = str(resumingnewcostsetsN) + " new cost sets to be resumed. From " + str(resumInd) + " - Start pt: " + str(resumSPt) + " - Matched pt: " + str(resumMPt)
				gp.AddWarning(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
			del TestRow, TestCur

	else:  # no previous output table found - start from scratch
		costsetN=0
		newcostsets=0
		if Debug=="true":
			message = "... Adding cost fields to output table"
			gp.AddWarning(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
		while CostRast1: # Adds fields according to number of cost sets
			costsetN=costsetN+1
			message = "Cost set " + str(costsetN) + ": " + CostRast1
			gp.AddMessage(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
			gp.Workspace = OutputWorkspace
			fieldname = "PATHC_C" + str(costsetN)
			gp.AddField_management(outputtable,fieldname,"double")  # Path cost
			gp.Workspace = CostWorkspace
			CostRast1 = CostRasters1.Next()

	del CostRasters1

except:
	message = "Problem in beginning!" + "\n" + gp.GetMessages()
	gp.AddError(message)
	OutFile.writelines(strftime('%c - ') + message + "\n")
	OutFile.close()
	del CostRasters1, fieldlist, TestCur
	if FROMTO != "":
		sendMail(subject_failure,[OutFile_name])
	sys.exit(2)

# Loop on observed points
if Debug=="true":
	message = "... Starting loop in observation points table"
	gp.AddWarning(message)
	OutFile.writelines(strftime('%c - ') + message + "\n")
ObsCur = gp.SearchCursor(Indiv_AllPoints)
ObsRow = ObsCur.Next()
NextObsCur = gp.SearchCursor(Indiv_AllPoints)
NextObsRow = NextObsCur.Next()
NextObsRow = NextObsCur.Next()
resumingindiv = 0
if resuming==1 and Nnewcostsets==0: # new points to be processed
	if ObsRow.GetValue(IndivIDField) != NextObsRow.GetValue(IndivIDField):
		message = "Resuming at a new individual"
		gp.AddWarning(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")
		resumingindiv = 0
		ObsRow = ObsCur.Next()
		NextObsRow = NextObsCur.Next()
	else:
		message = "Resuming at previous individual"
		gp.AddWarning(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")
		resumingindiv = 1
		prevX = ObsRow.GetValue(EastField)
		prevY = ObsRow.GetValue(NorthField)
		ObsRow = ObsCur.Next()
		NextObsRow = NextObsCur.Next()


# ---------------------------------------------------------------------------------------------------------------------------------------
# LOOP WITHIN TABLE OF OBSERVED POINTS
# ---------------------------------------------------------------------------------------------------------------------------------------
while NextObsRow: # start of individual

	try:
		# Initialisation for each individual
		# Creates Individual folder, extracts individual points, and creates feature classes
		IndivID = ObsRow.GetValue(IndivIDField)
		IndivID2 = IndivID.replace('-','')
		message = "\n==================================== " + str(IndivID) + " ========================================"
		gp.AddMessage(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")
		OutputWorkspaceIndiv = OutputWorkspace + "\\" + IndivID2

		if not gp.Exists(OutputWorkspaceIndiv):
			if Debug=="true":
				message = "... Creating individual folder"
				gp.AddWarning(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
			gp.CreateFolder_management(OutputWorkspace, IndivID2)
		else:
			if Debug=="true":
				message = "Individual folder " + IndivID2 + " already exists - skip creation"
				gp.AddWarning(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")

		indivptN = 0

		if resumingindiv == 1:
			indivptN = 1
			resumingindiv = 0 
	except:
		message = "PROBLEM in start of loop within table of observed points!\n" + gp.GetMessages()
		gp.AddError(message)
		OutFile.writelines(strftime('%c - ') + message + "\n")
		OutFile.close()
		del ObsCur, NextObsCur
		if FROMTO != "":
			sendMail(subject_failure,[OutFile_name])
		sys.exit(2)

	# -----------------------------------------------------------------------------------------------------------------------------------
	# LOOP WITHIN 1 INDIVIDUAL - start for each obs point (skip null distances), extract starting point and end point
	# -----------------------------------------------------------------------------------------------------------------------------------
	# 1- Loop through obs pts, stop when dist to next pt (dtnp) >0 within the same individual.
	# 2- Select obs pt.
	# 3- Select all the random pts falling into a doughnut around obs pt.
	# 4- Loop through selected random pts, extract cost distance.

	while NextObsRow and NextObsRow.GetValue(IndivIDField)==IndivID : # Loop within individual
		try:
			indivptN = indivptN + 1
			PathLength = 0.0

			# Skip points where no movement was recorded
			while NextObsRow and (pow(ObsRow.GetValue(EastField)-NextObsRow.GetValue(EastField),2)+pow(ObsRow.GetValue(NorthField)-NextObsRow.GetValue(NorthField),2))==0 and NextObsRow.GetValue(IndivIDField)==IndivID:
				ObsRow = ObsCur.Next()
				NextObsRow = NextObsCur.Next()
				if not ObsRow:
					message = "big pb1"
					gp.AddError(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
				if not NextObsRow:
					message = "big pb2"
					gp.AddError(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")

			if not NextObsRow:
				break
				message = "break1"
				gp.AddWarning(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")

			if NextObsRow.GetValue(IndivIDField) != IndivID:
				break
				message = "break2"
				gp.AddWarning(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")

			if indivptN == 1:
				prevX = ObsRow.GetValue(EastField)
				prevY = ObsRow.GetValue(NorthField)

			currX=ObsRow.GetValue(EastField)
			currY=ObsRow.GetValue(NorthField)
			currID=ObsRow.GetValue(PtField)

			nextX=NextObsRow.GetValue(EastField)
			nextY=NextObsRow.GetValue(NorthField)
			nextID=NextObsRow.GetValue(PtField)

			DistToNext = 0.0
			DistToNext = pow(pow(currX-nextX,2)+pow(currY-nextY,2),.5)

			# local variables, unique to each pair of points
			Indiv_Sel_source = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_SelectObsSource.shp"
			VegCovPolyg = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_VegCovPolyg.shp"
			VegCovDiss = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_VegCovPDiss.shp"
			PreDonutPts = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_PreDonutPts.shp"
			DonutPts = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_DonutPts.shp"
			SelRndPts = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_SelRndPts.shp"
			AllSelPts = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_AllSelPts.shp"
			PathCost = 0.0

			message = "\n   === " + str(IndivID) + " - #" + str(indivptN) + " - From " + str(currID) + " to " + str(nextID) + " - Distance " + str(round(DistToNext)) + " ==="
			gp.AddMessage(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")

			# Select source obs point
			if not gp.Exists(Indiv_Sel_source):
				gp.Select_analysis(Indiv_AllPoints, Indiv_Sel_source, '\"'+PtField+'\"='+str(int(currID)))
				if gp.GetCount_management(Indiv_Sel_source) == 0:
					gp.AddWarning(Indiv_Sel_source)
					gp.AddWarning('\"'+PtField+'\"='+str(int(currID)))
					gp.Select_analysis(Indiv_AllPoints, Indiv_Sel_source, '\"'+PtField+'\"='+str(int(currID)))

			gp.MakeFeatureLayer_management(Indiv_Sel_source, "SourcePt_lyr")
			if Debug=="true":
				message = "... Observed start point selected - currID=" + str(int(currID))
				gp.AddWarning(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
		except:
			message = "PROBLEM!\n" + gp.GetMessages()
			gp.AddError(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
			OutFile.close()
			del ObsCur, NextObsCur
			if FROMTO != "":
				sendMail(subject_failure,[OutFile_name])
			sys.exit(2)

		# Doughnut calculations for point selection
		num = 4*pow(DistToNext,2)-pow(DonutSize,2)
		if DistToNext > DonutSize*pow(2,0.5)/2:
			MinRadius = (pow(num,0.5)-DonutSize)/2
			MaxRadius = MinRadius + DonutSize
		else:
			MaxRadius = DistToNext*pow(2,0.5)
			MinRadius = 0
		if Debug=="true":
			message = "... Selection doughnut: MinRadius=" + str(MinRadius) + " - MaxRadius=" + str(MaxRadius)
			gp.AddWarning(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")

		if not gp.Exists(SelRndPts):
			try:    # Start Selection of alternative points and append to next obs pt -> AllSelPts
				# Preselection of random alternative points...
				gp.MakeFeatureLayer_management(RndPts, "RP_lyr")
				gp.SelectLayerByLocation_management("RP_lyr", "WITHIN_A_DISTANCE", "SourcePt_lyr", str(MaxRadius) + " METERS", "NEW_SELECTION")
				if DistToNext > DonutSize*pow(2,0.5)/2:
					gp.SelectLayerByLocation_management("RP_lyr", "WITHIN_A_DISTANCE", "SourcePt_lyr", str(MinRadius) + " METERS", "REMOVE_FROM_SELECTION")
				gp.CopyFeatures_management("RP_lyr", PreDonutPts)
				if Debug=="true":
					message = "... " + str(gp.GetCount_management(PreDonutPts)) + " pts in PreDonutPts"
					gp.AddWarning(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")

				# ... randomly keep one point per patch ...
				gp.MakeFeatureLayer_management(PreDonutPts, "layer")
				selcur = gp.SearchCursor(PreDonutPts)
				selrow = selcur.Next()
				while selrow:
					curpatch = selrow.GetValue("REFFID")
					record = 1
					while selrow and selrow.GetValue("REFFID")==curpatch:
						val = random.random()
						if val < record:
							record = val
							recFID = selrow.GetValue("FID")
						selrow=selcur.Next()
					gp.SelectLayerByAttribute_management("layer", "ADD_TO_SELECTION", "\"FID\"=" + str(recFID))
				del selrow, selcur
				gp.CopyFeatures_management("layer", DonutPts)
				NDonutPts=gp.GetCount_management(DonutPts)
				if Debug=="true":
					message = "... " + str(NDonutPts) + " pts in DonutPts"
					gp.AddWarning(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")

				# ... and finally select n points among preselected points
				ListRandIDs = random.sample(xrange(NDonutPts),NDonutPts)
				gp.AddField_management(DonutPts, "Rand_ID", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
				rndptcur = gp.UpdateCursor(DonutPts)
				rndpt = rndptcur.Next()
				while rndpt:
					for i in ListRandIDs:
						rndpt.Rand_ID = i
						rndptcur.UpdateRow(rndpt)
						rndpt=rndptcur.Next()
				del rndpt, rndptcur
				gp.Select_analysis(DonutPts, SelRndPts, "\"Rand_ID\" < " + str(NSelPts))
				NRndPts = gp.GetCount_management(SelRndPts)
				if Debug=="true":
					message = "... " + str(NRndPts) + " pts in SelRndPts"
					gp.AddWarning(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
				gp.AddField_management(SelRndPts, "Rnd_ID", "LONG", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
				gp.CalculateField_management(SelRndPts, "Rnd_ID", "["+RndPtIDField+"]")
				if NRndPts == 0:
					ObsRow = ObsCur.Next()
					NextObsRow = NextObsCur.Next()
					message = " No alternative pts around obs pt " + str(currID) + " - skipping...\n"
					gp.AddWarning(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
					continue     # Go to next obs pt
					# End of loop within obs pts / go to next record

				# Append next obs pt to set of selected random points
				gp.MakeFeatureLayer_management(Indiv_AllPoints, "layer2")
				gp.SelectLayerByAttribute_management("layer2", "NEW_SELECTION", "\"FID\"=" + str(NextObsRow.FID))
				gp.CopyFeatures_management("layer2", AllSelPts) # select next obs pt
				gp.AddField_management(AllSelPts, "Obs_ID", "LONG", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
				gp.AddField_management(AllSelPts, "Rnd_ID", "LONG", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
				gp.CalculateField_management(AllSelPts, "Obs_ID", "["+IndivIDField+"]")
				gp.Append_management(SelRndPts, AllSelPts, "NO_TEST")
				message = "      End points (observed and alternative): " + str(gp.GetCount_management(AllSelPts))
				gp.AddMessage(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")

			except: # End   Selection of alternative points and append to next obs pt -> AllSelPts
				message = "Problem in selection of alternative points!\n" + gp.GetMessages()
				gp.AddError(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
				OutFile.close()
				del ObsCur, NextObsCur, rndptcur, selcur
				if FROMTO != "":
					sendMail(subject_failure,[OutFile_name])
				sys.exit(2)

			try:    # Start Create and populate fields of AllSelPts
				gp.AddField_management(AllSelPts, "Angle", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
				gp.AddField_management(AllSelPts, "PathID", "TEXT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
				gp.AddField_management(AllSelPts, "ChoicePtN", "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
				gp.AddXY_management(AllSelPts)
				selcur2 = gp.UpdateCursor(AllSelPts)
				selrow2 = selcur2.Next()
				ChoicePt_i = 0
				Angles = []
				dPO = pow(pow(prevX-currX,2)+pow(prevY-currY,2),0.5)
				while selrow2:
					# Calculate angle field in AllSelPts - deviation from straight line coming from PrevPt
					if indivptN > 1:
						dOS = pow(pow(currX-selrow2.POINT_X,2)+pow(currY-selrow2.POINT_Y,2),0.5)
						dPS = pow(pow(prevX-selrow2.POINT_X,2)+pow(prevY-selrow2.POINT_Y,2),0.5)
						CosTheta = (pow(dPO,2)+pow(dOS,2)-pow(dPS,2))/(2*dPO*dOS)
						Theta = 0.0
						Theta = math.degrees(math.acos(CosTheta))
						Alpha = 180-Theta
					else:
						Alpha = 999
					Angles.append(Alpha)
					ChoicePt_i = ChoicePt_i + 1
					Path_ID = IndivID + "_" + str(int(currID)) + "to" + str(int(nextID)) + "_" + str(int(ChoicePt_i))
					selrow2.PathID = Path_ID
					selrow2.ChoicePtN = ChoicePt_i
					selrow2.Angle = Alpha
					if ChoicePt_i == 1:
						ObsAngle = Alpha
					selcur2.UpdateRow(selrow2)
					selrow2 = selcur2.Next()
				del selcur2
			except: # End   Create and populate fields of AllSelPts
				message = "Problem in creating and populating fields of AllSelPts!\n" + gp.GetMessages()
				gp.AddError(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
				OutFile.close()
				del ObsCur, NextObsCur, selcur2
				if FROMTO != "":
					sendMail(subject_failure,[OutFile_name])
				sys.exit(2)

		else: # Selection already done in a previous run
			try:
				if Debug=="true":
					message = "SelRndPts already exists - skip selection of alternative points"
					gp.AddWarning(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
				NRndPts = gp.GetCount_management(SelRndPts)
				if Debug=="true":
					message = "... " + str(NRndPts) + " pts in SelRndPts"
					gp.AddWarning(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
				if NRndPts == 0:
					ObsRow = ObsCur.Next()
					NextObsRow = NextObsCur.Next()
					message = " No alternative points around observation point " + str(currID) + " - skipping..."
					gp.AddWarning(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
					continue     # Go to next obs pt
				selcur3 = gp.SearchCursor(AllSelPts)
				selrow3 = selcur3.Next()
				Angles = []
				dPO = pow(pow(prevX-currX,2)+pow(prevY-currY,2),0.5)
				while selrow3:
					# Calculate angle field in AllSelPts - deviation from straight line coming from PrevPt
					if indivptN > 1:
						dOS = pow(pow(currX-selrow3.POINT_X,2)+pow(currY-selrow3.POINT_Y,2),0.5)
						dPS = pow(pow(prevX-selrow3.POINT_X,2)+pow(prevY-selrow3.POINT_Y,2),0.5)
						CosTheta = (pow(dPO,2)+pow(dOS,2)-pow(dPS,2))/(2*dPO*dOS)
						Theta = 0.0
						Theta = math.degrees(math.acos(CosTheta))
						Alpha = 180-Theta
					else:
						Alpha = 999
					selrow3 = selcur3.Next()
					Angles.append(Alpha)
				del selcur3
			except:
				message = "Problem in resuming AllSelPts!\n" + gp.GetMessages()
				gp.AddError(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
				OutFile.close()
				del ObsCur, NextObsCur, selcur3
				if FROMTO != "":
					sendMail(subject_failure,[OutFile_name])
				sys.exit(2)

		try:    # Start Extent calculation, land conversion and dissolve
			# Determine extent for all the random points for each obs pt,
			Xmin = int(currX-MaxRadius-ExtraRadius)
			Xmin = int(Xmin/15) * 15 + 5    # snap coordinates to veg cov raster...
			Xmax = int(currX+MaxRadius+ExtraRadius)
			Xmax = int(Xmax/15) * 15 + 5
			Ymin = int(currY-MaxRadius-ExtraRadius)
			Ymin = int(Ymin/15) * 15 - 5
			Ymax = int(currY+MaxRadius+ExtraRadius)
			Ymax = int(Ymax/15) * 15 - 5
			CalcExtent = str(Xmin) + " " + str(Ymin) + " " + str(Xmax) + " " + str(Ymax)    #square centered on source point, dimension depends on Dist2NextP + user-defined extra
			if Debug=="true":
				message = "... Extent= " + CalcExtent
				gp.AddWarning(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")

		except: # End   Extent calculation, land conversion and dissolve
			message = "Problem before LC loop!\n" + gp.GetMessages()
			gp.AddError(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
			OutFile.close()
			del ObsCur, NextObsCur
			if FROMTO != "":
				sendMail(subject_failure,[OutFile_name])
			sys.exit(2)

		choiceptcur = gp.SearchCursor(AllSelPts)
		choicept = choiceptcur.Next()
		choiceptN = 0

		# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------
		# LOOP WITHIN TABLE OF CHOICE POINTS (L-C path calculation for each point in AllSelPts)
		# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------
		while choicept:
			try:
				if pow(pow(choicept.POINT_X-currX,2) + pow(choicept.POINT_Y-currY,2),0.5) < CellSize*pow(2,0.5):
					# paths shorter than cell size cause problems -> skip this point
					message = "Path too short, skip point!\n"
					gp.AddWarning(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
					choicept = choiceptcur.Next()
					choiceptN = choiceptN + 1
					continue
				gp.Workspace = CostWorkspace
				CostRasters = gp.ListRasters("*")
				CostRasters.reset()
				CostRast = CostRasters.Next()
				choiceptN = choiceptN + 1
				if firstCStoprocess>1:
					for i in range(1,firstCStoprocess):
						CostRast = CostRasters.Next() # move cost set cursor to first new cost set
					costsetN = Nprevcostsets # will be increased by 1 at start of CS loop
					if resumingnewcostsets:
						costsetN = firstCStoprocess - 1
				else:
					costsetN = 0
				if choiceptN==1:
					choiceptID = int(choicept.GetValue("Obs_ID"))
				else:
					choiceptID = int(choicept.GetValue("Rnd_ID"))
				message = "\n      --- Matched point " + str(choiceptN) + " (" + str(choiceptID) + ") ---"
				gp.AddMessage(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")

				# test for existence of dispersal path in output table if updating -  skip point if not there
				if firstCStoprocess>1:
					condtxt = "\"INDIV\"= '" + IndivID + "' AND \"STARTPT\"=" + str(currID)
					testrows = gp.SearchCursor(outputtable,condtxt)
					testrow = testrows.next()
					if not testrow:
						message = "path not found, skip dispersal path..."
						gp.AddWarning(message)
						OutFile.writelines(strftime('%c - ') + message + "\n")
						choicept = choiceptcur.Next()
						choiceptN = choiceptN + 1
						del testrows
						continue
					del testrows

			except:
				message = "Problem just before loop on cost sets!\n" + gp.GetMessages()
				gp.AddError(message)
				OutFile.writelines(strftime('%c - ') + message + "\n")
				OutFile.close()
				del ObsCur, NextObsCur, choiceptcur, CostRasters
				if FROMTO != "":
					sendMail(subject_failure,[OutFile_name])
				sys.exit(2)

			# ---------------------------------------------------------------------------------------------------------------------------------------------------------------
			# LOOP WITHIN FOLDER OF COST RASTERS
			# ---------------------------------------------------------------------------------------------------------------------------------------------------------------
			while CostRast:
				try:    # Start Preparation to least-cost path
					SameCell = False
					gp.Extent = CalcExtent
					costsetN = costsetN + 1
					if Debug=="true":
						message = "... using cost set " + str(costsetN) + ": " + CostRast
						gp.AddWarning(message)
						OutFile.writelines(strftime('%c - ') + message + "\n")
					gp.Workspace = OutputWorkspace

					# Prepare output row (new row or update depending on situation)
					if firstCStoprocess>1: # if new cost sets or resuming new cost sets
						if costsetN == firstCStoprocess:
							condtxt = "\"INDIV\"= '" + IndivID + "' AND \"STARTPT\"=" + str(currID) + " AND \"MATCHPT\"=" + str(choiceptN)
							OutputRows = gp.UpdateCursor(outputtable, condtxt)
							OutputRow = OutputRows.next()
					else:
						if costsetN == 1: # new line for obs pt (different cost sets in different fields)
							OutputRows = gp.InsertCursor(outputtable)
							OutputRow = OutputRows.NewRow()
							OutputRow.Indiv = IndivID
							OutputRow.StartPt = currID
							OutputRow.EndPt = nextID
							OutputRow.MatchPt = choiceptN
						if choiceptN > 1: # for alternative points
							OutputRow.Choice = 0
							OutputRow.MatchID = choiceptID
						else:   # for observed end point
							OutputRow.Choice = 1
							OutputRow.MatchID = 0
					if not gp.Exists(OutputWorkspaceIndiv + "\\CostSet" + str(costsetN)):
						if Debug=="true":
							message = "... Creating Cost folder"
							gp.AddWarning(message)
							OutFile.writelines(strftime('%c - ') + message + "\n")
						gp.CreateFolder_management(OutputWorkspaceIndiv, "CostSet" + str(costsetN))

					DestPt = OutputWorkspaceIndiv + "\\" + IndivID2 + "_ObsPt" + str(currID) + "_AltPt" + str(choiceptN) + ".shp"

					gp.Workspace = CostWorkspace
				except: # End   Preparation to least-cost path
					message = "Problem in preparation to least-cost path!\n" + gp.GetMessages()
					gp.AddError(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
					OutFile.close()
					del ObsCur, NextObsCur, choiceptcur, CostRasters, OutputRows
					if FROMTO != "":
						sendMail(subject_failure,[OutFile_name])
					sys.exit(2)

				try:    # Start Calculate Least-cost path
					# Cost Distance calculation - same for every simulated points and the observed one
					if Debug=="true":
						message = "... " + str(gp.GetCount_management("SourcePt_lyr")) + " features in SourcePt_lyr"
						gp.AddWarning(message)
						OutFile.writelines(strftime('%c - ') + message + "\n")
					gp.CostDistance_sa("SourcePt_lyr", CostRast, CostDist, "", Backlink) # Indiv_Sel_source
					if Debug=="true":
						message = "... Finished cost distance"
						gp.AddWarning(message)
						OutFile.writelines(strftime('%c - ') + message + "\n")

					# Least-cost path
					DestPtNb = choicept.GetValue("FID")
					Cond_dest = "\"FID\" =" + str(int(DestPtNb))
					if not gp.Exists(DestPt):
						gp.Select_analysis(AllSelPts, DestPt, Cond_dest)
					if Debug=="true":
						message = "... Finished cost path"
						gp.AddWarning(message)
						OutFile.writelines(strftime('%c - ') + message + "\n")

					# Extract Path cost value from raster
					gp.ZonalStatisticsAsTable_sa(DestPt, IndivIDField, CostDist, temppath + "\\temp_table.dbf", "DATA")
					CostP_cur = gp.SearchCursor(temppath + "\\temp_table.dbf")
					CostP_row = CostP_cur.Next()
					PathCost = CostP_row.GetValue("MAX")
					del CostP_cur
					if Debug=="true":
						message = "... Extracted path cost ("+str(round(PathCost,2))+")"
						gp.AddWarning(message)
						OutFile.writelines(strftime('%c - ') + message + "\n")
					fieldname = "PATHC_C"+ str(costsetN)
					gp.AddMessage(fieldname + "= " + str(PathCost))
					OutputRow.SetValue(fieldname, PathCost)

				except: # End   Calculate Least-cost path
					message = "Failed in processing least-cost path...!!!\n" + gp.GetMessages()
					gp.AddError(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
					OutFile.close()
					del ObsCur, NextObsCur, choiceptcur, CostRasters, OutputRows, CostP_cur
					if FROMTO != "":
						sendMail(subject_failure,[OutFile_name])
					sys.exit(2)

				try:    
					message = "         Cost Set " + str(costsetN) + " - Cost: " + str(round(PathCost,1)) + " - Angle: " + str(round(Angles[choiceptN-1],1))
					gp.AddMessage(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
				except: 
					message = "Error in field creation and calculation in PathLine!\n" + gp.GetMessages()
					gp.AddError(message)
					OutFile.writelines(strftime('%c - ') + message + "\n")
					OutFile.close()
					del ObsCur, NextObsCur, choiceptcur, CostRasters, OutputRows
					if FROMTO != "":
						sendMail(subject_failure,[OutFile_name])
					sys.exit(2)

				gp.Workspace = CostWorkspace
				CostRast = CostRasters.Next()
				# End of loop within cost rasters

			if firstCStoprocess == 1:
				OutputRows.InsertRow(OutputRow)
			else:
				OutputRows.UpdateRow(OutputRow)
			choicept = choiceptcur.Next()
			gp.Extent = GlobalExtent
			del CostRasters, OutputRows
			# Go to next choice point
			# End of loop within choice points (for each obs pt)

		try:
			prevX = currX
			prevY = currY
			ObsRow = ObsCur.Next()
			NextObsRow = NextObsCur.Next()
			del choiceptcur
		except:
			message = "Problem at the end of loop within 1 individual\n" + gp.GetMessages()
			gp.AddError(message)
			OutFile.writelines(strftime('%c - ') + message + "\n")
			OutFile.close()
			if FROMTO != "":
				sendMail(subject_failure,[OutFile_name])
			sys.exit(2)
		# Go to next obs pt
		# End of loop within individual

	if NextObsRow and (NextObsRow.GetValue(IndivIDField) != IndivID) and (ObsRow.GetValue(IndivIDField)==IndivID):
		ObsRow = ObsCur.Next()
		NextObsRow = NextObsCur.Next()
	# End of loop within obs table

# End of obs pts

del ObsCur, NextObsCur
message = strftime('%c') + ": Script finished successfully!!!"
gp.AddMessage(message)
OutFile.writelines("\n" + message)
OutFile.close()

if FROMTO != "":
	sendMail(subject_success,[OutFile_name,outputtable])

del ExtraRadius, DonutSize, NSelPts
del VegCov_r, OutputWorkspace, Indiv_AllPoints, IndivID, IndivID2
del indivptN, PathLength, choiceptN, currID, nextID
del Indiv_Sel_source, CostDist 
del SelRndPts, PathCost, currX, nextX, currY, nextY, DistToNext
del MinRadius, MaxRadius, curpatch, record, val, recFID, ListRandIDs, choiceptcur, choicept
del Xmin, Xmax, Ymin, Ymax, CalcExtent, DestPtNb, Cond_dest
