# ---------------------------------------------------------------------------
# IFPC.py
# 
# Index of Functional Patch Connectivity
# by Yvan Richard - y.richard@massey.ac.nz
# ---------------------------------------------------------------------------


import sys, string, os, arcgisscripting

# Create the Geoprocessor object and get path to scratch workspace
gp = arcgisscripting.create()
scratchWS = gp.scratchWorkspace
if scratchWS:
    desc = gp.Describe(scratchWS)
    if desc.WorkspaceType <> "FileSystem":
        scratchWS = gp.GetSystemEnvironment("TEMP")
else:
    scratchWS = gp.GetSystemEnvironment("TEMP")

# Check out any necessary licenses
gp.CheckOutExtension("spatial")

# Load required toolboxes...
gp.AddToolbox("C:/Program Files/= GIS =/ArcGIS/ArcToolbox/Toolboxes/Spatial Analyst Tools.tbx")
gp.AddToolbox("C:/Program Files/= GIS =/ArcGIS/ArcToolbox/Toolboxes/Analysis Tools.tbx")
gp.AddToolbox("C:/Program Files/= GIS =/ArcGIS/ArcToolbox/Toolboxes/Data Management Tools.tbx")
gp.OverwriteOutput=1
gp.AddWarning("Warning: Overwrite ON")

# Script arguments...
CostRaster = sys.argv[1]
FocalPatches = sys.argv[2]
LandPatches = sys.argv[3]
if LandPatches == '#':
    LandPatches = sys.argv[2] # if no layer is specified, use the first one
Radius = sys.argv[4]
OutputWorkspace = sys.argv[5]
CreatePaths = sys.argv[6]
if CreatePaths == '#':
    CreatePaths = "false"

# Local variables...
Copy_FocalPatches = OutputWorkspace + "\\Patches_IFPC.shp"
Output_backlink_raster = ""
PLayer = "Patches_Layer"
LCost = 0.0
PArea = 0.0
Restart = 0

NPatches = gp.GetCount_management(FocalPatches)
gp.AddMessage("")
gp.AddMessage(str(NPatches) + " patches to be processed")

# Create patch cursor and retrieve first patch
Patch_cur = gp.SearchCursor(FocalPatches)
Patch_row = Patch_cur.Next()

# Extract data elements from landscape patches layer to work on...
gp.MakeFeatureLayer_management(LandPatches, PLayer, "", OutputWorkspace, "ID ID VISIBLE;GRIDCODE GRIDCODE VISIBLE;AREA AREA VISIBLE;PERIMETER PERIMETER VISIBLE")
if not gp.Exists(Copy_FocalPatches):
    # Create a copy of focal patches layer (will have new IFPC attribute)...
    gp.CopyFeatures_management(FocalPatches, Copy_FocalPatches, "", "0", "0", "0")
else:
    output_rows = gp.SearchCursor(Copy_FocalPatches)
    Restart = 1

# Add IFPC field to copy of focal patches layer
try:
    gp.AddField_management(Copy_FocalPatches, "IFPC", "FLOAT", "12", "2", "", "", "NULLABLE", "NON_REQUIRED", "")
except:
    gp.AddError("Warning: Couldn't add field 'IFPC'. Field already exists or unwritable layer? Skip...")
    gp.AddError(gp.GetMessages(2))

patchN = 0

# * Loop through the focal patches *
while Patch_row:

    patchN = patchN + 1
    try:
        PatchId = str(int(Patch_row.GetValue("GRIDCODE")))

        # Local variables...
        PathDist = scratchWS + "PathD_P"
        FocalPatch_layer = "FocalPatch_Layer"
        SelPatches = scratchWS + "Patches_sel.shp" # Polygon layer with neighbour patches
        ZonalStats = scratchWS + "ZonalStats.dbf"  
        IFC = 0.0
        already_done = 0.0

        if CreatePaths == "true":
            Backlink = scratchWS + "\\Backlink_P" 
            CostPath = OutputWorkspace + "\\LC_Paths_P" + PatchId

        if Restart == 1:
            output_row = output_rows.Next()
            already_done = output_row.GetValue("IFPC")
            
        if already_done == 0:
            
            # Geoprocessing extent is set according to the focal patch extent and the surroundings
            Geom = Patch_row.shape
            PExtent = Geom.Extent
            Xmin = float(string.splitfields(PExtent," ")[0]) - float(Radius) - 1000
            Ymin = float(string.splitfields(PExtent," ")[1]) - float(Radius) - 1000
            Xmax = float(string.splitfields(PExtent," ")[2]) + float(Radius) + 1000
            Ymax = float(string.splitfields(PExtent," ")[3]) + float(Radius) + 1000
            PExtent = str(Xmin) +" "+ str(Ymin) +" "+ str(Xmax) +" "+ str(Ymax)
            gp.extent = PExtent
            
            # Select neighbouring patches...
            gp.MakeFeatureLayer_management(FocalPatches, FocalPatch_layer, "\"GRIDCODE\" ="  + PatchId, OutputWorkspace, "ID ID VISIBLE;GRIDCODE GRIDCODE VISIBLE;AREA AREA VISIBLE;PERIMETER PERIMETER VISIBLE")
            gp.SelectLayerByLocation_management(PLayer, "WITHIN_A_DISTANCE", FocalPatch_layer, Radius + " Meters", "NEW_SELECTION")    ##"2000.000000 Meters" [ + " Meters"]
            gp.CopyFeatures_management(PLayer, SelPatches, "", "0", "0", "0")

            # Path Distance...
            if CreatePaths == "false":
                gp.CostDistance_sa(FocalPatch_layer, CostRaster, PathDist, "", Output_backlink_raster)
            else:
                gp.CostDistance_sa(FocalPatch_layer, CostRaster, PathDist, "", Backlink)
            
            try:
                # Add field 'COST' to SelPatches (surrounding patches)
                gp.AddField_management(SelPatches, "COST", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
            except:
                gp.AddError("Warning: Couldn't add COST field. Field already exists or unwritable layer? Skip...")
                gp.AddError(gp.GetMessages(2))

            # Zonal Statistics as Table to extract path cost...
            gp.ZonalStatisticsAsTable_sa(SelPatches, "GRIDCODE", PathDist, ZonalStats, "DATA")

            # Create a row cursor to extract cost path value of each patch
            dbf_rows = gp.SearchCursor(ZonalStats)
            dbf_row = dbf_rows.Next()

            # Loop in surrounding patches to update COST field
            while dbf_row:
                
                LCost = dbf_row.GetValue("MIN")
                Patch = dbf_row.GetValue("VALUE")
                PArea = dbf_row.GetValue("AREA")

                if not LCost == 0:
                    IFC = IFC + PArea/LCost
                    
                Cond2 = "\"GRIDCODE\" =" + str(Patch)
                UpdRows = gp.UpdateCursor(SelPatches,Cond2)
                UpdRow = UpdRows.Next()
                UpdRow.COST = int(LCost)
                UpdRows.UpdateRow(UpdRow)
                dbf_row = dbf_rows.Next()

            del dbf_rows, UpdRows
            gp.AddMessage("  - Patch " + str(PatchId ) + " (" + str(patchN) + "/" + str(NPatches) + "): IFPC= " + str(IFC))

            if CreatePaths == "true":
                # Creates least cost path rasters
                gp.CostPath_sa(SelPatches, PathDist, Backlink, CostPath, "EACH_ZONE", "GRIDCODE")

            # Update IFPC of FocalPatches
            Cond3 = "\"GRIDCODE\" =" + PatchId
            UpdFocalPRows = gp.UpdateCursor(Copy_FocalPatches,Cond3)
            UpdFocalPRow = UpdFocalPRows.Next()
            UpdFocalPRow.IFPC = IFC
            UpdFocalPRows.UpdateRow(UpdFocalPRow)
                            
        else:
            gp.AddMessage(" - already done (IFPC=" + str(already_done) + "), skip patch...")

        Patch_row = Patch_cur.Next()
        
    except:
        gp.AddError("Error in patches loop...!!!")
        gp.AddError(gp.GetMessages(2))
        sys.exit(1)

del Patch_cur, Patch_row
if already_done == 0:
    del UpdFocalPRows, UpdFocalPRow
if Restart == 1:
    del output_rows, output_row
gp.AddMessage("")
